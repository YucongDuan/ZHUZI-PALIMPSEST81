from __future__ import annotations
import argparse, json
from pathlib import Path
from .core import *
def emit(x): print(json.dumps(x,ensure_ascii=False,indent=2))
def main(argv=None):
    p=argparse.ArgumentParser(prog='zhuzi-palimp81')
    s=p.add_subparsers(dest='cmd',required=True)
    for n in ['summary','constitution','list-schools','list-tensions','list-scenarios','list-layers','list-rewrite-events','selftest']: s.add_parser(n)
    x=s.add_parser('show-school'); x.add_argument('school')
    x=s.add_parser('genealogy'); x.add_argument('school')
    x=s.add_parser('resolve'); x.add_argument('tension')
    x=s.add_parser('scenario'); x.add_argument('scenario')
    x=s.add_parser('show-event'); x.add_argument('event')
    x=s.add_parser('simulate-witness'); x.add_argument('school'); x.add_argument('relation',choices=['support','conflict','missing_voice','redaction'])
    x=s.add_parser('evaluate-policy'); x.add_argument('json_file')
    x=s.add_parser('evaluate-history'); x.add_argument('json_file')
    a=p.parse_args(argv)
    if a.cmd=='summary': emit(summary())
    elif a.cmd=='constitution': emit(load('ultimate_constitution.json'))
    elif a.cmd=='list-schools': emit([{'id':x['id'],'name_cn':x['name_cn'],'evidence_state':x['historiography']['evidence_state']} for x in load('schools.json')])
    elif a.cmd=='list-tensions': emit([{'id':x['id'],'title_cn':x['title_cn'],'formula_cn':x['formula_cn']} for x in load('tensions.json')])
    elif a.cmd=='list-scenarios': emit([{'id':x['id'],'title_cn':x['title_cn']} for x in load('scenarios.json')])
    elif a.cmd=='list-layers': emit(load('history_layers.json'))
    elif a.cmd=='list-rewrite-events': emit(load('rewrite_events.json'))
    elif a.cmd=='show-school': emit(school(a.school))
    elif a.cmd=='genealogy': emit({'school':school(a.school),'layers':load('history_layers.json')})
    elif a.cmd=='resolve': emit({'tension':tension(a.tension),'ultimate':load('ultimate_constitution.json')})
    elif a.cmd=='scenario':
        c=scenario(a.scenario); emit({'scenario':c,'tensions':[tension(t) for t in c['tensions']],'ultimate':load('ultimate_constitution.json')})
    elif a.cmd=='show-event': emit(event(a.event))
    elif a.cmd=='simulate-witness': emit(simulate_witness(a.school,a.relation))
    elif a.cmd=='evaluate-policy': emit(evaluate_policy(json.loads(Path(a.json_file).read_text(encoding='utf-8'))))
    elif a.cmd=='evaluate-history': emit(evaluate_history(json.loads(Path(a.json_file).read_text(encoding='utf-8'))))
    elif a.cmd=='selftest':
        r=selftest(); emit(r); return 0 if r['passed'] else 1
    return 0
