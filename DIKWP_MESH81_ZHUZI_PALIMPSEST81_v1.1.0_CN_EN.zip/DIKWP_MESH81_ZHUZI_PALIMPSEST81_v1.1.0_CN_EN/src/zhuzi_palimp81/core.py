from __future__ import annotations
import json, hashlib
from importlib.resources import files
from typing import Any

def load(name:str)->Any:
    return json.loads(files('zhuzi_palimp81').joinpath('data',name).read_text(encoding='utf-8'))

def digest(obj:Any)->str:
    return hashlib.sha256(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def summary():
    data={k:load(k+'.json') for k in ['schools','tensions','scenarios','history_layers','rewrite_events','sources']}
    u=load('ultimate_constitution.json')
    return {'system':'DIKWP-MESH8.1 ZHUZI-PALIMPSEST81','version':'1.1.0','schools':len(data['schools']),'tensions':len(data['tensions']),'scenarios':len(data['scenarios']),'history_layers':len(data['history_layers']),'rewrite_events':len(data['rewrite_events']),'sources':len(data['sources']),'ultimate_value':u['name_cn'],'core_digest':digest({'data':data,'ultimate':u})}

def find(items,q,fields):
    q=q.lower()
    for x in items:
        if any(q==str(x.get(f,'')).lower() or q in str(x.get(f,'')).lower() for f in fields): return x
    raise KeyError(q)

def school(q): return find(load('schools.json'),q,['id','name_cn','alias_en'])
def tension(q): return find(load('tensions.json'),q,['id','title_cn'])
def scenario(q): return find(load('scenarios.json'),q,['id','title_cn'])
def event(q): return find(load('rewrite_events.json'),q,['id','title_cn'])

POLICY_CHECKS={
'D':['equal_status','evidence_trace','historical_sources_returnable'],
'I':['dissent_preserved','minority_protection','public_voice'],
'K':['expertise_selection','evidence_trace','future_ecology'],
'W':['equal_status','minority_protection','future_ecology','historical_sources_returnable'],
'P':['appeal','revocation','independent_review','public_voice']}
POLICY_REC={
'equal_status':'基本尊严与基本权利不得随能力、身份或贡献分级。','expertise_selection':'公开职责能力要求，区分专业判断与终极价值决定。','public_voice':'为受影响普通人建立实质参与。','dissent_preserved':'保存异议、少数与地方经验。','evidence_trace':'记录事实、来源、规则版本和推断过程。','appeal':'建立可用且无报复的申诉渠道。','revocation':'设置任期、撤回、罢免、日落或回滚机制。','minority_protection':'对弱势和少数设置不可抵消保护。','future_ecology':'把生态承载力和代际后果纳入决定。','independent_review':'适当分离提出、执行、评价和批准角色。','historical_sources_returnable':'公共叙事必须能返回原始来源、异本和修订记录。'}

def evaluate_policy(policy):
    pos={}; missing=[]
    for p,fields in POLICY_CHECKS.items():
        fail=[f for f in fields if not bool(policy.get(f))]
        pos[p]=0 if fail else 1; missing+=fail
    unique=list(dict.fromkeys(missing))
    return {'title':policy.get('title','untitled'),'vector':''.join(str(pos[p]) for p in 'DIKWP'),'positions':pos,'open_obligations':[{'field':f,'recommendation':POLICY_REC[f]} for f in unique],'ultimate_value':'共生成全—史源可返','claim_boundary':'结构义务，不构成历史真义、法律合规或现实成功认证。'}

HIST_CHECKS={
'D':['source_witnesses','transmission_chain'],
'I':['variant_witnesses','redaction_hypotheses','missing_voices'],
'K':['scope_boundary','redaction_hypotheses'],
'W':['power_context','normative_layer_separated'],
'P':['reopen_conditions','independent_review','transmission_chain']}

def present(v): return bool(v) and v!=[]
def evaluate_history(claim):
    pos={}; missing=[]
    for p,fields in HIST_CHECKS.items():
        fail=[f for f in fields if not present(claim.get(f))]
        if p=='I' and not claim.get('hostile_source_assessed',False): fail.append('hostile_source_assessed')
        pos[p]=0 if fail else 1; missing+=fail
    return {'claim':claim.get('claim',''),'vector':''.join(str(pos[p]) for p in 'DIKWP'),'positions':pos,'open_obligations':list(dict.fromkeys(missing)),'status':'CURRENT_RECONSTRUCTION' if all(pos.values()) else 'HISTORICAL_K_REMAINS_OPEN','terminal_rule':'终极W稳定；历史K必须可重开。'}

def simulate_witness(school_id,relation='conflict'):
    s=school(school_id); relation=relation.lower()
    delta={'support':'新增D：新见证与当前重构保持部分同源。','conflict':'新增I：新见证与当前重构不可无损合并。','missing_voice':'新增I：此前缺席主体获得直接或间接见证。','redaction':'新增P/I：发现删定或传递链改变。'}.get(relation,'新增I：未分类的新见证。')
    return {'school_id':s['id'],'relation':relation,'delta':delta,'old_K_status':'CURRENT_RECONSTRUCTION','new_K_status':'REOPENED_APPEND_ONLY','required_actions':['保留旧K及其版本','登记见证来源与物质语境','更新异本与删改假说','重新审查现代发展命题','发布差分而非覆盖旧结论']}

def selftest():
    errors=[]
    sm=summary()
    for k,n in [('schools',12),('tensions',18),('scenarios',10),('history_layers',9),('rewrite_events',12)]:
        if sm[k]!=n: errors.append(k)
    good={'equal_status':1,'expertise_selection':1,'public_voice':1,'dissent_preserved':1,'evidence_trace':1,'appeal':1,'revocation':1,'minority_protection':1,'future_ecology':1,'independent_review':1,'historical_sources_returnable':1}
    if evaluate_policy(good)['vector']!='11111': errors.append('policy')
    if simulate_witness('SCHOOL_MO','conflict')['new_K_status']!='REOPENED_APPEND_ONLY': errors.append('witness')
    return {'passed':not errors,'errors':errors,'checks':8,'summary':sm}
