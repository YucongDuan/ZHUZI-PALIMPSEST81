import sys,json
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'src'))
from zhuzi_palimp81.core import *
T=[]
def c(n,x):T.append((n,bool(x)))
s=summary();c('counts',s['schools']==12 and s['history_layers']==9 and s['rewrite_events']==12)
c('mohist',school('墨家')['id']=='SCHOOL_MO')
c('event',event('E03')['id']=='E03')
c('witness',simulate_witness('SCHOOL_MO','conflict')['new_K_status']=='REOPENED_APPEND_ONLY')
good=json.loads((root/'examples'/'historical_claims'/'mohist_merit_claim_good.json').read_text(encoding='utf-8'));c('history_vector',evaluate_history(good)['vector']=='11111')
pol=json.loads((root/'examples'/'policies'/'mohist_merit_council.json').read_text(encoding='utf-8'));c('policy_vector',evaluate_policy(pol)['vector']=='11111')
c('selftest',selftest()['passed'])
for n,x in T:print(('PASS' if x else 'FAIL'),n)
print(sum(x for _,x in T),'passed,',sum(not x for _,x in T),'failed')
raise SystemExit(0 if all(x for _,x in T) else 1)
