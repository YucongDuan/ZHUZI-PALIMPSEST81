# DIKWP-MESH8.1 ZHUZI-PALIMPSEST81（百家复层81）

诸子百家史层解码、缺席声音恢复与“共生成全—史源可返”文明宪制系统。

## 终极解法

> 终极不是终止历史，而是终止任何权力把自己的历史版本设为不可重开。

- 任责有等，尊严无等。
- 共识可统，意义不可强同。
- 能者可任，任者可问。
- 古文可传，解释不可垄断。
- 出土可重开，不等于原本终审。
- 终极 W 稳定，历史 K 永远可返。

## 运行

```bash
python dist/ZhuziPalimp81.pyz summary
python dist/ZhuziPalimp81.pyz list-layers
python dist/ZhuziPalimp81.pyz genealogy 墨家
python dist/ZhuziPalimp81.pyz show-event E03
python dist/ZhuziPalimp81.pyz simulate-witness SCHOOL_MO conflict
python dist/ZhuziPalimp81.pyz evaluate-history examples/historical_claims/mohist_merit_claim_good.json
python dist/ZhuziPalimp81.pyz evaluate-policy examples/policies/mohist_merit_council.json
python dist/ZhuziPalimp81.pyz selftest
```

直接打开 `site/index.html`。
